<?Php 
session_start();
if($_SESSION["user"] == true)
{}
else{
  header('location:login form.php');
}

echo "welcome"." ".$_SESSION["user"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <meta charset="UTF-8">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <title>Blood Bank Management System </title>
</head>
<body>

    <div class="menu-bar">
    <ul>
   <li class="active"><a href="#">Home</a><i class='bx bxs-home'></i></li>
   <li><a href="#">Donate</a><i class='bx bxs-donate-blood'></i>
      <div Class="sub-menu-1">
         <ul>
             <li> <a href="eventspage.php">Blood Donation</a></li>
             <li> <a href="OrganregistrationForm.php">organ Donation</a></li>
        </ul>
     </div>
</li>
<li><a href="image hover.html">Eligible<i class='bx bx-question-mark'></i></a></li>
   <li><a href="#">Stocks<i class='bx bxs-bar-chart-alt-2'></i> 
     <div Class="sub-menu-1">
       <ul>
        <li> <a href="bloodRequired.page.new.php">Blood </a></li>
        <li> <a href="organrequired.php">Organ </a></li>
       </ul>
   </div>
</li>
   <li><a href="eventspage.php">Events</a><i class='bx bxs-calendar' ></i></li>
   <li><a href="contact2.php">Contact</a><i class='bx bxs-phone'></i></li>
   <li><a href="logout.php"> log out</a><i class='bx bxs-log-out' ></i></li>
    </ul>
</div> <br>
<br>
<br>
<br>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
		img{
			width: 100%;
			height: 450px;
		}
		 #slider{
		 	width: 1000px;
		 	height: 480px;
		 	margin: 20px auto;
		 	position: relative;
		 	border: 10px solid white;
		 	box-shadow: 0px 0px 5px 2px #ccc;
		 }
		 
		 button{
		 	padding: 20px;
		 	border: none;
		 	background: rgb(241, 119, 119);
		 	font-size: 30px;
		 	color: white;
		 	position: absolute;
		 	top:45%;
		 	cursor: pointer;
		 }

        .next{
        	border-radius: 10px 0px 0px 10px;
        	margin-left: 950px;
        }
        .prew{
        	border-radius: 0px 10px 10px 0px;
        }

	</style>
</head>
<body>
  <marquee  style="color: rED;" >  <a href="eventspage.php" > <STRONG> ****   EVENT'S PAGE IS UPDATED CHECK IT OUT  ****  </STRONG></a></marquee>

  <br>
  <br>

	<div id="slider">
		<div id="box">
			<img src="blood2.jpg">
		</div>

		<!-- buttons for controls slider -->
		<button class="prew fa fa-chevron-left" onclick="prewImage()"></button>
		<button class="next fa fa-chevron-right" onclick="nextImage()"></button>
	</div>



  <script type="text/javascript">

  	var slider_content = document.getElementById('box');

  	// contain images in an array
    var image = ['blood2','blood3', 'blood4', 'whatdonorcando','organ5'];

    var i = image.length;


    // function for next slide 

    function nextImage(){
    	if (i<image.length) {
    		i= i+1;
    	}else{
    		i = 1;
    	}
    	  slider_content.innerHTML = "<img src="+image[i-1]+".jpg>";
    }


    // function for prew slide

    function prewImage(){

    	if (i<image.length+1 && i>1) {
    		i= i-1;
    	}else{
    		i = image.length;
    	}
    	  slider_content.innerHTML = "<img src="+image[i-1]+".jpg>";

    }

  
  // script for auto image slider

  setInterval(nextImage , 4000);

  </script>
 <br>
<br>
<br>
<section class="text-gray-600 body-font">
    <div class="container mx-auto flex px-5 py-24 md:flex-row flex-col items-center">
      <div class="lg:flex-grow md:w-1/2 lg:pr-24 md:pr-16 flex flex-col md:items-start md:text-left mb-16 md:mb-0 items-center text-center">
        <h1 class="title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900"> Donate For A Needy Person 
          <br class="hidden lg:inline-block">
        </h1>
        <p class="mb-8 leading-relaxed">BLOOD GROUPS
            blood group of any human being will mainly fall in any one of the following groups.<br>
            
            A positive or A negative<br>
            B positive or B negative <br>
            O positive or O negative <br> 
            AB positive or AB negative. <br>
            A healthy diet helps ensure a successful blood donation, and also makes you feel better!<br>
             Check out the following recommended foods to eat prior to your donation.</p>
        <div class="flex justify-center">
         
        </div>
      </div>
      <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6">
        <img class="object-cover object-center rounded" alt="hero" src="foodbedonate.jpg">
      </div>
    </div> <hr> 
    <section class="text-gray-600 body-font">
      <div class="container mx-auto flex px-5 py-24 md:flex-row flex-col items-center">
        <div class="lg:max-w-lg lg:w-full md:w-1/2 w-5/6 mb-10 md:mb-0">
          <img class="object-cover object-center rounded" alt="hero" src="regesternow.jpg">
        </div>
        <div class="lg:flex-grow md:w-1/2 lg:pl-24 md:pl-16 flex flex-col md:items-start md:text-left items-center text-center">
          <h1 class="title-font sm:text-4xl text-3xl mb-4 font-medium text-gray-900"> what is Blood Donation ?
            <br class="hidden lg:inline-block">
          </h1>
          <p class="mb-8 leading-relaxed">Blood donation is when a person voluntarily gives blood, which can be used for blood transfusions or to make certain drugs. Blood banks store this blood. The blood can be used to help the victims of accidents, for example. Usually, the blood donor and the donated blood are tested for diseases which spread through the blood. These include various forms of Hepatitis,HIV and Syphilis. Usually, a series of questions also need to be answered to make sure that there is no risk to the person donating.

            A special case of blood donation sometimes occurs before a dangerous medical operation. People donate their own blood, which can be used after the operation if they lose too much blood.</p>
          <div class="flex justify-center">
          </div>
        </div>
      </div>
    </section> <hr>

   

            <div class="container">
              <div class="timeline">
                <ul>
                  <li>
                    <div class="timeline-content">
                      
                      <h1>STEP 1</h1>
                      <p>First check the events page and register according .</p>
                    </div>
                  </li>
                  <li>
                    <div class="timeline-content">
                      
                      <h1>STEP 2</h1>
                      <p> After registeration check the location and reach on .</p>
                    </div>
                  </li>
                  <li>
                    <div class="timeline-content">
                     
                      <h1>STEP 3</h1>
                      <p>Reach on the time you have defined.</p>
                    </div>
                  </li>
                  <li>
                    <div class="timeline-content">
                      
                      <h1>STEP 4</h1>
                      <p>Just go in and do your donation and every things is done.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <footer>
  <p class="text-center">Copyright &copy; BBOMS</p>
</footer>

</body>
</html>
