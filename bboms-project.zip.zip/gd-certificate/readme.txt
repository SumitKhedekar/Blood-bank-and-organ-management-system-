Keep all the files in one directory and open the index.html file from any location accessed by your server path. 
Detail tutorial with video is available at 

 https://www.plus2net.com/php_tutorial/gd-certificate.php

Use the contact us page at www.plus2net.com to reach us. 

This is downloaded from www.plus2net.com 
Please don't  remove the link to www.plus2net.com 
This is for your learning only not for commercial use. 
The author is not responsible for any type of loss or problem or damage on using this script.
You can use it at your own risk.
